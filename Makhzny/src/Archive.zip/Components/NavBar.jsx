import React, { useState, useEffect } from 'react';
import logo from '../assets/logo.png';
import { NavLink, useNavigate } from 'react-router-dom';
import { useLang } from '../contexts/LanguageContext';
import '../Styles/NavBar.css';

function NavBar() {
  const navigate = useNavigate();
  const [MobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { lang, setLang, t } = useLang();
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const [token, setToken] = useState(localStorage.getItem('token'));

useEffect(() => {
  const handleStorageChange = () => {
    setToken(localStorage.getItem('token'));
  };

  window.addEventListener('storage', handleStorageChange);
  return () => {
    window.removeEventListener('storage', handleStorageChange);
  };
}, []);
  const [userName, setUserName] = useState(null);

  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem('user'));
    if (storedUser?.id) {
      setUserName("مستخدم"); // مؤقتًا، لحد ما تجيب الاسم من API
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setShowUserMenu(false);
    navigate('/');
    window.location.reload();
  };

  const closeMenu = () => setMobileMenuOpen(false);

  return (
    <div className='Nav-Bar'>
      <div className="navbar-box">
        <div className="Nav-logo">
          <img src={logo} alt="logo" />
        </div>

        <div className="hamburger" onClick={() => setMobileMenuOpen(prev => !prev)}>
          ☰
        </div>

        <div className={MobileMenuOpen ? "menu-content open" : "menu-content"}>
          <ul className="nav-links">
            <li><NavLink to="/" onClick={closeMenu} className={({ isActive }) => isActive ? 'active-link' : ''}>{t('home')}</NavLink></li>
            <li><NavLink to="/RentNow" onClick={closeMenu} className={({ isActive }) => isActive ? 'active-link' : ''}>{t('rentNow')}</NavLink></li>
            <li><NavLink to="/RequestQuote" onClick={closeMenu} className={({ isActive }) => isActive ? 'active-link' : ''}>{t('requestQuote')}</NavLink></li>
            <li><NavLink to="/TransferRequest" onClick={closeMenu} className={({ isActive }) => isActive ? 'active-link' : ''}>{t('moving')}</NavLink></li>
            <li><NavLink to="/howitWorks" onClick={closeMenu} className={({ isActive }) => isActive ? 'active-link' : ''}>{t('howItWorks')}</NavLink></li>
            <li><NavLink to="/GetInTouch" onClick={closeMenu} className={({ isActive }) => isActive ? 'active-link' : ''}>{t('getInTouch')}</NavLink></li>
            <li className="dropdown-parent">
              <span onClick={() => setDropdownOpen(prev => !prev)} className="plus-toggle">
                <span className={`arrow-icon ${dropdownOpen ? 'open' : ''}`}></span>
              </span>
              <ul className={`dropdown-menu ${dropdownOpen ? 'show' : ''}`}>
                <li><NavLink to="/BecomePartner" onClick={closeMenu} className={({ isActive }) => isActive ? 'active-link' : ''}>{t('becomePartner')}</NavLink></li>
                <li><NavLink to="/FAQ" onClick={closeMenu} className={({ isActive }) => isActive ? 'active-link' : ''}>{t('faq')}</NavLink></li>
              </ul>
            </li>
          </ul>

          {MobileMenuOpen && (
            <div className="right-controls mobile-only">
              <div className="flags">
                <select
                  value={lang}
                  onChange={(e) => {
                    const newLang = e.target.value;
                    setLang(newLang);
                    document.body.dir = newLang === 'ar' ? 'rtl' : 'ltr';
                  }}
                >
                  <option value="en">🇬🇧 EN</option>
                  <option value="ar">🇸🇦 AR</option>
                </select>
              </div>

              {token ? (
                <div className="user-dropdown">
                  <span
                    className="user-name"
                    onClick={() => setShowUserMenu((prev) => !prev)}
                    style={{ cursor: 'pointer' }}
                  >
                    👤 {userName || t('logout')} ▾
                  </span>
                  {showUserMenu && (
                    <ul className="dropdown-logout">
                      <li onClick={handleLogout}>{t('logout')}</li>
                    </ul>
                  )}
                </div>
              ) : (
                <button onClick={() => navigate('/LogIn')}>{t('signIn')}</button>
              )}
            </div>
          )}
        </div>

        <div className="right-controls desktop-only">
          <div className="flags">
            <select
              value={lang}
              onChange={(e) => {
                const newLang = e.target.value;
                setLang(newLang);
                document.body.dir = newLang === 'ar' ? 'rtl' : 'ltr';
              }}
            >
              <option value="en">🇬🇧 EN</option>
              <option value="ar">🇸🇦 AR</option>
            </select>
          </div>

          {token ? (
            <div className="user-dropdown">
              <span
                className="user-name"
                onClick={() => setShowUserMenu((prev) => !prev)}
                style={{ cursor: 'pointer' }}
              >
                👤 {userName || t('logout')} ▾
              </span>
              {showUserMenu && (
                <ul className="dropdown-logout">
                  <li onClick={handleLogout}>{t('logout')}</li>
                </ul>
              )}
            </div>
          ) : (
            <button onClick={() => navigate('/LogIn')}>{t('signIn')}</button>
          )}
        </div>
      </div>
    </div>
  );
}

export default NavBar;
